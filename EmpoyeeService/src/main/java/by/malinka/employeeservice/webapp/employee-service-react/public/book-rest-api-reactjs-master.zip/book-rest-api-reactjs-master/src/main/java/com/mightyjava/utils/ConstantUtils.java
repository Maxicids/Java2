package com.mightyjava.utils;

public enum ConstantUtils {
	ADMIN, USER
}
